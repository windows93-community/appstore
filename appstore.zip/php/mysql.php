<?php if(!isset($conn)) $conn = new mysqli("sql207.epizy.com", "epiz_25969459", 'mXafEw8cEvtWK', "epiz_25969459_appstore"); ?>
