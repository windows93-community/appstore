<?php include "mysql.php" ?>
<html>
  <head>
    <title> AppStore93 </title>
    <link rel="stylesheet" href="./res/style.css">
    <!-- <link rel="stylesheet" href="./res/98.css"> -->
  </head>
  <body>
    <div id="navbar">
      <div class="navleft">
        Search apps: <input type="text" name="search">
      </div>
      <div class="navright">
         <strong> appstore 93 </strong>
      </div>
    </div>
   <div style="margin-bottom: 50px;"></div>
